package Entidades;

//import java.util.concurrent.TimeUnit;

public class ExecutionTime1 
{

	public static void main(String[] args) throws InterruptedException 
	{
		int count = 0;
		for (;;) 
		{
			try 
			{
				Thread.sleep(1000);
				count++;
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(count);
		}
	}
}
