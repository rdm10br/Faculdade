package Entidades;

public class Products extends KeyR
{	
	private int jump;
	private int gravity;
	private int moveFwrd;
	private int moveBckwrd;
	public int getJump() {
		return jump;
	}
	public void setJump(int jump) {
			
		this.jump = jump;
	}
	public int getGravity() {
		return gravity;
	}
	public void setGravity(int gravity) {
		this.gravity = gravity;
	}
	public int getMoveFwrd() {
		return moveFwrd;
	}
	public void setMoveFwrd(int moveFwrd) {
		this.moveFwrd = moveFwrd;
	}
	public int getMoveBckwrd() {
		return moveBckwrd;
	}
	public void setMoveBckwrd(int moveBckwrd) {
		this.moveBckwrd = moveBckwrd;
	}
	
}

