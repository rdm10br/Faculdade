package Entidades;

import java.io.IOException;
import java.io.InputStreamReader;

public class KeyR {

	public void keyR(){
		
		InputStreamReader inputStreamReader = new InputStreamReader(System.in);		
		System.out.println();
		try {
		inputStreamReader.read();
		} 
		catch (IOException e) {			
		       e.printStackTrace();
		}
		}

}
