import Entidades.Products;


public class Main {

	public static void main(String[] args) 
	{
		Products product = new Products();
		//System.out.println("opa e ai mue bom vo printar as coisas aqui");
		product.getMoveFwrd();
		System.out.println(product.getMoveFwrd());
	}

}
